require('dotenv').config();
const express = require('express');
const session = require('express-session');
const { google } = require('googleapis');
const { v4: uuidv4 } = require('uuid');
const fs   = require('fs');
const path = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, 'data');
const PUB  = path.join(__dirname, 'public');

if (!fs.existsSync(DATA)) fs.mkdirSync(DATA, { recursive: true });
if (!fs.existsSync(PUB))  fs.mkdirSync(PUB,  { recursive: true });

// ─── OAuth2 ────────────────────────────────────────────────────────────────────
const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  `http://localhost:${PORT}/auth/callback`
);

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'crm-shakuf-secret-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

// ─── Auth Middleware ──────────────────────────────────────────────────────────
const ADMIN_PASSWORD   = process.env.ADMIN_PASSWORD   || 'changeme';
const RECOVERY_CODE    = process.env.RECOVERY_CODE    || 'shakuf-restore-2024';

function requirePassword(req, res, next) {
  if (req.session && req.session.authenticated) return next();
  if (req.path === '/login' || req.path === '/login.html') return next();
  if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Unauthorized' });
  res.redirect('/login.html');
}

app.get('/login', (req, res) => {
  if (req.session && req.session.authenticated) return res.redirect('/');
  res.sendFile(path.join(PUB, 'login.html'));
});

app.post('/login', (req, res) => {
  const { password } = req.body;
  if (password === ADMIN_PASSWORD || password === RECOVERY_CODE) {
    req.session.authenticated = true;
    res.json({ ok: true });
  } else {
    res.status(401).json({ error: 'סיסמה שגויה' });
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

app.use(requirePassword);
app.use(express.static(PUB));

// ─── JSON Storage ─────────────────────────────────────────────────────────────
const today = () => new Date().toISOString().split('T')[0];
const uid   = () => uuidv4().slice(0, 8);

function rj(file, def = []) {
  const fp = path.join(DATA, file);
  if (!fs.existsSync(fp)) return def;
  try { return JSON.parse(fs.readFileSync(fp, 'utf8')); } catch { return def; }
}
function wj(file, data) {
  fs.writeFileSync(path.join(DATA, file), JSON.stringify(data, null, 2), 'utf8');
}

// ─── Token Persistence ────────────────────────────────────────────────────────
function loadStoredTokens() {
  const fp = path.join(DATA, 'tokens.json');
  if (!fs.existsSync(fp)) return null;
  try { return JSON.parse(fs.readFileSync(fp, 'utf8')); } catch { return null; }
}
function storeTokens(tokens) {
  wj('tokens.json', tokens);
}

// Background auth client (no request session needed)
function bgAuth() {
  const tokens = loadStoredTokens();
  if (!tokens) return null;
  const client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET
  );
  client.setCredentials(tokens);
  // Auto-persist refreshed tokens
  client.on('tokens', refreshed => {
    storeTokens({ ...tokens, ...refreshed });
  });
  return client;
}

// ─── Sample data ──────────────────────────────────────────────────────────────
function init() {
  if (rj('orgs.json').length === 0) {
    wj('orgs.json', [
      { id:'org1', name:'מרכז תרבות רמת גן', industry:'תרבות ובידור', phone:'03-1234567', email:'culture@rg.muni.il', city:'רמת גן', status:'warm', source:'המלצה', notes:'מעוניינים במופע לחנוכה', tags:['תרבות'], conversations:[], showHistory:[], nextFollowUp:'2026-04-20', googleContactId:null, createdAt:'2026-03-01' },
      { id:'org2', name:'עיריית נתניה — מחלקת תרבות', industry:'מגזר ציבורי', phone:'09-8765432', email:'culture@netanya.muni.il', city:'נתניה', status:'booked', source:'יוזמה עצמית', notes:'אישרו הרצאה. ממתין לחוזה.', tags:['עירייה'], conversations:[], showHistory:[{id:'sh1',date:'2026-03-13',venue:'אולם תרבות נתניה',showType:'הרצאה',status:'scheduled',fee:'2500',notes:''}], nextFollowUp:'', googleContactId:null, createdAt:'2026-02-15' }
    ]);
  }
  if (rj('contacts.json').length === 0) {
    wj('contacts.json', [
      { id:'c1', name:'דנה לוי', organizationId:'org1', role:'מנהלת תרבות', phone:'052-1234567', email:'dana@rg.muni.il', city:'רמת גן', status:'warm', source:'', notes:'איש קשר ראשי', tags:[], conversations:[{id:'cv1',date:'2026-03-20',type:'call',content:'שיחה ראשונית — מעוניינת במופע לחנוכה'}], showHistory:[], nextFollowUp:'2026-04-20', googleContactId:null, createdAt:'2026-03-20' },
      { id:'c2', name:'אבי כהן', organizationId:null, role:'', phone:'054-9876543', email:'avi@gmail.com', city:'תל אביב', status:'vip', source:'מופע', notes:'חובב נלהב! היה בשלושה מופעים.', tags:['VIP'], conversations:[{id:'cv2',date:'2026-02-14',type:'whatsapp',content:'שלח הודעה אחרי המופע — מאוד נהנה!'}], showHistory:[{id:'sh2',date:'2026-02-14',venue:'תיאטרון הבימה',showType:'מופע רגיל',status:'completed',fee:'',notes:''}], nextFollowUp:'', googleContactId:null, createdAt:'2025-10-01' },
      { id:'c3', name:'יוסי מזרחי', organizationId:'org2', role:'מנהל תרבות', phone:'050-8765432', email:'yossi@netanya.muni.il', city:'נתניה', status:'booked', source:'', notes:'', tags:[], conversations:[], showHistory:[], nextFollowUp:'', googleContactId:null, createdAt:'2026-02-15' }
    ]);
  }
  if (rj('tasks.json').length === 0) {
    wj('tasks.json', [
      { id:'t1', title:'לשלוח הצעת מחיר לדנה לוי', type:'task', contactId:'c1', organizationId:'org1', conversationId:'cv1', dueDate:'2026-04-20', startDateTime:null, endDateTime:null, location:null, completed:false, googleEventId:null, googleTaskId:null, notes:'לכלול מופע לחנוכה עם אופציה לסדנה', priority:'high', createdAt:'2026-04-01' },
      { id:'t2', title:'מופע נתניה — פורים', type:'event', contactId:'c3', organizationId:'org2', conversationId:null, dueDate:'2026-04-13', startDateTime:'2026-04-13T19:00:00', endDateTime:'2026-04-13T21:00:00', location:'אולם תרבות נתניה', completed:false, googleEventId:null, googleTaskId:null, notes:'לוודא ציוד סאונד מראש', priority:'high', createdAt:'2026-02-20' }
    ]);
  }
}
init();

// ─── Auth ─────────────────────────────────────────────────────────────────────
const SCOPES = [
  'https://www.googleapis.com/auth/calendar',
  'https://www.googleapis.com/auth/tasks',
  'https://www.googleapis.com/auth/contacts',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
];

app.get('/auth/google', (req, res) => {
  if (!process.env.GOOGLE_CLIENT_ID) return res.redirect('/?auth=no-config');
  const url = oauth2Client.generateAuthUrl({ access_type:'offline', scope:SCOPES, prompt:'consent' });
  res.redirect(url);
});

app.get('/auth/callback', async (req, res) => {
  try {
    const { tokens } = await oauth2Client.getToken(req.query.code);
    req.session.tokens = tokens;
    oauth2Client.setCredentials(tokens);
    storeTokens(tokens);  // persist for background sync
    const oauth2 = google.oauth2({ version:'v2', auth:oauth2Client });
    const { data } = await oauth2.userinfo.get();
    req.session.userInfo = data;
    wj('userinfo.json', data);
    res.redirect('/?auth=success');
  } catch (e) {
    res.redirect('/?auth=error&msg=' + encodeURIComponent(e.message));
  }
});

app.get('/auth/status', (req, res) => {
  const ss = rj('sync-status.json', {});
  res.json({
    authenticated: !!req.session.tokens || !!loadStoredTokens(),
    user: req.session.userInfo || rj('userinfo.json', null),
    googleConfigured: !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
    lastSync: ss,
    autoSyncActive: !!(loadStoredTokens()),
  });
});

app.post('/auth/logout', (req, res) => {
  req.session.destroy();
  // Remove persisted tokens
  const fp = path.join(DATA, 'tokens.json');
  if (fs.existsSync(fp)) fs.unlinkSync(fp);
  const uf = path.join(DATA, 'userinfo.json');
  if (fs.existsSync(uf)) fs.unlinkSync(uf);
  res.json({ ok:true });
});

function requireAuth(req, res, next) {
  if (!req.session.tokens) return res.status(401).json({ error:'לא מחובר לגוגל' });
  oauth2Client.setCredentials(req.session.tokens);
  next();
}

// ─── Background Sync Helpers ──────────────────────────────────────────────────

function buildPersonBody(item, isOrg, orgMap = {}) {
  return {
    names:          [{ givenName: item.name }],
    phoneNumbers:   item.phone ? [{ value: item.phone }] : [],
    emailAddresses: item.email ? [{ value: item.email }] : [],
    addresses:      item.city  ? [{ city: item.city, country:'Israel' }] : [],
    organizations:  isOrg
      ? [{ name: item.name, type:'work' }]
      : (item.organizationId && orgMap[item.organizationId]
          ? [{ name: orgMap[item.organizationId].name, title: item.role||'' }]
          : []),
    biographies: [{ value: `[CRM-ID: ${item.id}]\n${item.notes||''}`.trim() }],
  };
}

async function pushContactOrOrgToGoogle(item, isOrg) {
  const auth = bgAuth(); if (!auth) return;
  const ppl = google.people({ version:'v1', auth });
  const file = isOrg ? 'orgs.json' : 'contacts.json';
  const list = rj(file);
  const idx  = list.findIndex(i => i.id === item.id);
  if (idx === -1) return;
  const orgMap = Object.fromEntries(rj('orgs.json').map(o=>[o.id,o]));
  const body = buildPersonBody(item, isOrg, orgMap);

  try {
    if (item.googleContactId) {
      const { data:cur } = await ppl.people.get({ resourceName:item.googleContactId, personFields:'metadata' });
      await ppl.people.updateContact({
        resourceName: item.googleContactId,
        updatePersonFields: 'names,phoneNumbers,emailAddresses,addresses,organizations,biographies',
        requestBody: { ...body, etag: cur.etag },
      });
      console.log(`[Auto-sync] Updated Google Contact: ${item.name}`);
    } else {
      const { data } = await ppl.people.createContact({ requestBody: body });
      list[idx].googleContactId = data.resourceName;
      wj(file, list);
      console.log(`[Auto-sync] Created Google Contact: ${item.name}`);
    }
  } catch (e) {
    // Contact deleted in Google – recreate
    try {
      const { data } = await ppl.people.createContact({ requestBody: body });
      list[idx].googleContactId = data.resourceName;
      wj(file, list);
    } catch (e2) { console.error('[Auto-sync] Contact push error:', e2.message); }
  }
}

async function deleteContactFromGoogle(googleContactId) {
  const auth = bgAuth(); if (!auth || !googleContactId) return;
  try {
    const ppl = google.people({ version:'v1', auth });
    await ppl.people.deleteContact({ resourceName: googleContactId });
    console.log(`[Auto-sync] Deleted Google Contact: ${googleContactId}`);
  } catch (e) { console.error('[Auto-sync] Delete contact error:', e.message); }
}

async function pushTaskToGoogle(item) {
  const auth = bgAuth(); if (!auth) return;
  const tasks = rj('tasks.json');
  const idx   = tasks.findIndex(t => t.id === item.id);
  if (idx === -1) return;

  if (item.type === 'event') {
    const cal  = google.calendar({ version:'v3', auth });
    const body = {
      summary:     item.title,
      description: [item.notes||'', `[CRM-ID: ${item.id}]`].filter(Boolean).join('\n'),
      location:    item.location || '',
      start: item.startDateTime
        ? { dateTime: new Date(item.startDateTime).toISOString(), timeZone:'Asia/Jerusalem' }
        : { date: item.dueDate },
      end: item.endDateTime
        ? { dateTime: new Date(item.endDateTime).toISOString(), timeZone:'Asia/Jerusalem' }
        : { date: item.dueDate },
    };
    try {
      if (item.googleEventId) {
        await cal.events.update({ calendarId:'primary', eventId:item.googleEventId, requestBody:body });
        console.log(`[Auto-sync] Updated Calendar event: ${item.title}`);
      } else {
        const { data } = await cal.events.insert({ calendarId:'primary', requestBody:body });
        tasks[idx].googleEventId = data.id;
        wj('tasks.json', tasks);
        console.log(`[Auto-sync] Created Calendar event: ${item.title}`);
      }
    } catch (e) { console.error('[Auto-sync] Event push error:', e.message); }

  } else {
    const gtasks = google.tasks({ version:'v1', auth });
    const body = {
      title:  item.title,
      notes:  [item.notes||'', `[CRM-ID: ${item.id}]`].filter(Boolean).join('\n'),
      due:    item.dueDate ? new Date(item.dueDate + 'T00:00:00+02:00').toISOString() : undefined,
      status: item.completed ? 'completed' : 'needsAction',
    };
    try {
      if (item.googleTaskId) {
        await gtasks.tasks.update({ tasklist:'@default', task:item.googleTaskId, requestBody:body });
        console.log(`[Auto-sync] Updated Google Task: ${item.title}`);
      } else {
        const { data } = await gtasks.tasks.insert({ tasklist:'@default', requestBody:body });
        tasks[idx].googleTaskId = data.id;
        wj('tasks.json', tasks);
        console.log(`[Auto-sync] Created Google Task: ${item.title}`);
      }
    } catch (e) { console.error('[Auto-sync] Task push error:', e.message); }
  }
}

async function deleteEventFromGoogle(googleEventId) {
  const auth = bgAuth(); if (!auth || !googleEventId) return;
  try {
    const cal = google.calendar({ version:'v3', auth });
    await cal.events.delete({ calendarId:'primary', eventId:googleEventId });
    console.log(`[Auto-sync] Deleted Calendar event: ${googleEventId}`);
  } catch (e) { console.error('[Auto-sync] Delete event error:', e.message); }
}

async function deleteTaskFromGoogle(googleTaskId) {
  const auth = bgAuth(); if (!auth || !googleTaskId) return;
  try {
    const gtasks = google.tasks({ version:'v1', auth });
    await gtasks.tasks.delete({ tasklist:'@default', task:googleTaskId });
    console.log(`[Auto-sync] Deleted Google Task: ${googleTaskId}`);
  } catch (e) { console.error('[Auto-sync] Delete task error:', e.message); }
}

// ─── Background Pull (Google → CRM) ──────────────────────────────────────────
let lastPollTime = null;

async function pullFromGoogle() {
  const auth = bgAuth(); if (!auth) return { pulled:0 };
  let pulled = 0;
  const since = lastPollTime ? new Date(lastPollTime).toISOString() : null;

  try {
    // Pull Calendar events
    const cal     = google.calendar({ version:'v3', auth });
    let   items   = rj('tasks.json');
    const existGE = new Set(items.filter(i=>i.googleEventId).map(i=>i.googleEventId));
    const tMin    = since || new Date(Date.now() - 30*24*60*60*1000).toISOString();
    const { data:evData } = await cal.events.list({
      calendarId:'primary', timeMin:tMin, singleEvents:true, orderBy:'startTime', maxResults:200
    });
    for (const ev of evData.items || []) {
      if (existGE.has(ev.id)) continue;
      if ((ev.description||'').includes('[CRM-ID:')) continue;
      items.unshift({
        id:uid(), title:ev.summary||'אירוע', type:'event',
        contactId:null, organizationId:null, conversationId:null,
        dueDate:  ev.start?.date || ev.start?.dateTime?.split('T')[0] || today(),
        startDateTime: ev.start?.dateTime||null, endDateTime:ev.end?.dateTime||null,
        location: ev.location||null, completed: ev.status==='cancelled',
        googleEventId: ev.id, googleTaskId:null,
        notes: ev.description||'', priority:'normal',
        createdAt:today(), fromGoogle:true,
      });
      pulled++;
    }

    // Pull Google Tasks
    const gtasks  = google.tasks({ version:'v1', auth });
    const existGT = new Set(items.filter(i=>i.googleTaskId).map(i=>i.googleTaskId));
    const gtQuery = since ? { tasklist:'@default', maxResults:100, updatedMin:since } : { tasklist:'@default', maxResults:100 };
    const { data:gtData } = await gtasks.tasks.list(gtQuery);
    for (const gt of gtData.items || []) {
      if (existGT.has(gt.id)) continue;
      if ((gt.notes||'').includes('[CRM-ID:')) continue;
      items.unshift({
        id:uid(), title:gt.title||'משימה', type:'task',
        contactId:null, organizationId:null, conversationId:null,
        dueDate: gt.due ? gt.due.split('T')[0] : '',
        startDateTime:null, endDateTime:null, location:null,
        completed: gt.status==='completed',
        googleEventId:null, googleTaskId:gt.id,
        notes:gt.notes||'', priority:'normal',
        createdAt:today(), fromGoogle:true,
      });
      pulled++;
    }

    if (pulled > 0) { wj('tasks.json', items); console.log(`[Auto-sync] Pulled ${pulled} items from Google`); }
  } catch(e) { console.error('[Auto-sync] Pull error:', e.message); }

  // Pull new Google Contacts
  try {
    const ppl    = google.people({ version:'v1', auth });
    const conts  = rj('contacts.json');
    const existC = new Set(conts.filter(c=>c.googleContactId).map(c=>c.googleContactId));
    let pageToken, newConts = 0;
    do {
      const { data } = await ppl.people.connections.list({
        resourceName:'people/me', pageSize:200, pageToken,
        personFields:'names,phoneNumbers,emailAddresses,addresses,organizations,biographies',
        ...(since ? { requestSyncToken:false } : {}),
      });
      for (const gp of data.connections||[]) {
        if (existC.has(gp.resourceName)) continue;
        const bio = gp.biographies?.[0]?.value||'';
        if (bio.includes('[CRM-ID:')) continue;
        conts.unshift({
          id:uid(), name:gp.names?.[0]?.displayName||'ללא שם',
          organizationId:null, role:gp.organizations?.[0]?.title||'',
          phone:gp.phoneNumbers?.[0]?.value||'', email:gp.emailAddresses?.[0]?.value||'',
          city:gp.addresses?.[0]?.city||'', status:'lead', source:'Google Contacts',
          notes:bio, tags:[], conversations:[], showHistory:[], nextFollowUp:'',
          googleContactId:gp.resourceName, createdAt:today(), fromGoogle:true,
        });
        newConts++; pulled++;
      }
      pageToken = data.nextPageToken;
    } while (pageToken);
    if (newConts > 0) { wj('contacts.json', conts); console.log(`[Auto-sync] Pulled ${newConts} contacts from Google`); }
  } catch(e) { console.error('[Auto-sync] Pull contacts error:', e.message); }

  lastPollTime = new Date().toISOString();
  const ss = rj('sync-status.json', {});
  ss.lastAutoPull = lastPollTime;
  ss.autoSyncEnabled = true;
  if (pulled > 0) ss.lastPullCount = pulled;
  wj('sync-status.json', ss);

  return { pulled };
}

// ─── CRUD with auto-sync hooks ────────────────────────────────────────────────
function crud(file, hooks = {}) {
  return {
    list: (req,res) => res.json(rj(file)),

    create: (req,res) => {
      const items = rj(file);
      const item  = { id:uid(), createdAt:today(), ...req.body };
      items.unshift(item);
      wj(file, items);
      res.json(item);
      if (hooks.onSave) hooks.onSave(item).catch(e=>console.error('[Auto-sync]',e.message));
    },

    update: (req,res) => {
      const items = rj(file);
      const idx   = items.findIndex(i => i.id === req.params.id);
      if (idx === -1) return res.status(404).json({ error:'לא נמצא' });
      items[idx] = { ...items[idx], ...req.body, updatedAt:today() };
      wj(file, items);
      res.json(items[idx]);
      if (hooks.onSave) hooks.onSave(items[idx]).catch(e=>console.error('[Auto-sync]',e.message));
    },

    remove: (req,res) => {
      const items = rj(file);
      const item  = items.find(i => i.id === req.params.id);
      wj(file, items.filter(i => i.id !== req.params.id));
      res.json({ ok:true });
      if (hooks.onDelete && item) hooks.onDelete(item).catch(e=>console.error('[Auto-sync]',e.message));
    },
  };
}

const O = crud('orgs.json', {
  onSave:   item => pushContactOrOrgToGoogle(item, true),
  onDelete: item => item.googleContactId ? deleteContactFromGoogle(item.googleContactId) : Promise.resolve(),
});
const C = crud('contacts.json', {
  onSave:   item => pushContactOrOrgToGoogle(item, false),
  onDelete: item => item.googleContactId ? deleteContactFromGoogle(item.googleContactId) : Promise.resolve(),
});
const T = crud('tasks.json', {
  onSave:   item => pushTaskToGoogle(item),
  onDelete: item => Promise.all([
    item.googleEventId ? deleteEventFromGoogle(item.googleEventId) : Promise.resolve(),
    item.googleTaskId  ? deleteTaskFromGoogle(item.googleTaskId)   : Promise.resolve(),
  ]),
});

app.get('/api/orgs',        O.list);
app.post('/api/orgs',       O.create);
app.put('/api/orgs/:id',    O.update);
app.delete('/api/orgs/:id', O.remove);

app.get('/api/contacts',        C.list);
app.post('/api/contacts',       C.create);
app.put('/api/contacts/:id',    C.update);
app.delete('/api/contacts/:id', C.remove);

app.get('/api/tasks',        T.list);
app.post('/api/tasks',       T.create);
app.put('/api/tasks/:id',    T.update);
app.delete('/api/tasks/:id', T.remove);

// ─── Manual Full Sync (kept for Settings page) ────────────────────────────────
app.post('/api/sync/calendar', requireAuth, async (req, res) => {
  try {
    const cal    = google.calendar({ version:'v3', auth:oauth2Client });
    const gtasks = google.tasks({ version:'v1', auth:oauth2Client });
    const items  = rj('tasks.json');
    const conts  = rj('contacts.json');
    const orgs   = rj('orgs.json');
    const result = { pushed:0, updated:0, pulled:0, errors:[] };

    const buildDesc = (t) => {
      const cont = conts.find(c => c.id === t.contactId);
      const org  = orgs.find(o => o.id === t.organizationId);
      return [t.notes||'', cont?`איש קשר: ${cont.name}`:'', org?`ארגון: ${org.name}`:'', `[CRM-ID: ${t.id}]`].filter(Boolean).join('\n');
    };

    for (const t of items.filter(i => i.type === 'event')) {
      const body = {
        summary:     t.title, description: buildDesc(t), location: t.location||'',
        start: t.startDateTime ? { dateTime:new Date(t.startDateTime).toISOString(), timeZone:'Asia/Jerusalem' } : { date:t.dueDate },
        end:   t.endDateTime   ? { dateTime:new Date(t.endDateTime).toISOString(),   timeZone:'Asia/Jerusalem' } : { date:t.dueDate },
      };
      try {
        if (t.googleEventId) { await cal.events.update({ calendarId:'primary', eventId:t.googleEventId, requestBody:body }); result.updated++; }
        else { const { data } = await cal.events.insert({ calendarId:'primary', requestBody:body }); t.googleEventId = data.id; result.pushed++; }
      } catch(e) { result.errors.push({ id:t.id, err:e.message }); }
    }

    for (const t of items.filter(i => i.type === 'task')) {
      const body = { title:t.title, notes:buildDesc(t), due:t.dueDate?new Date(t.dueDate+'T00:00:00+02:00').toISOString():undefined, status:t.completed?'completed':'needsAction' };
      try {
        if (t.googleTaskId) { await gtasks.tasks.update({ tasklist:'@default', task:t.googleTaskId, requestBody:body }); result.updated++; }
        else { const { data } = await gtasks.tasks.insert({ tasklist:'@default', requestBody:body }); t.googleTaskId = data.id; result.pushed++; }
      } catch(e) { result.errors.push({ id:t.id, err:e.message }); }
    }

    const existingGEids = new Set(items.filter(i=>i.googleEventId).map(i=>i.googleEventId));
    const tMin = new Date(); tMin.setMonth(tMin.getMonth() - 1);
    const { data:evData } = await cal.events.list({ calendarId:'primary', timeMin:tMin.toISOString(), singleEvents:true, orderBy:'startTime', maxResults:200 });
    for (const ev of evData.items||[]) {
      if (existingGEids.has(ev.id)) continue;
      if ((ev.description||'').includes('[CRM-ID:')) continue;
      items.unshift({ id:uid(), title:ev.summary||'אירוע', type:'event', contactId:null, organizationId:null, conversationId:null, dueDate:ev.start?.date||ev.start?.dateTime?.split('T')[0]||today(), startDateTime:ev.start?.dateTime||null, endDateTime:ev.end?.dateTime||null, location:ev.location||null, completed:ev.status==='cancelled', googleEventId:ev.id, googleTaskId:null, notes:ev.description||'', priority:'normal', createdAt:today(), fromGoogle:true });
      result.pulled++;
    }

    const existingGTids = new Set(items.filter(i=>i.googleTaskId).map(i=>i.googleTaskId));
    const { data:gtData } = await gtasks.tasks.list({ tasklist:'@default', maxResults:100 });
    for (const gt of gtData.items||[]) {
      if (existingGTids.has(gt.id)) continue;
      if ((gt.notes||'').includes('[CRM-ID:')) continue;
      items.unshift({ id:uid(), title:gt.title, type:'task', contactId:null, organizationId:null, conversationId:null, dueDate:gt.due?gt.due.split('T')[0]:'', startDateTime:null, endDateTime:null, location:null, completed:gt.status==='completed', googleEventId:null, googleTaskId:gt.id, notes:gt.notes||'', priority:'normal', createdAt:today(), fromGoogle:true });
      result.pulled++;
    }

    wj('tasks.json', items);
    const ss = rj('sync-status.json',{}); ss.calendar = new Date().toISOString(); wj('sync-status.json', ss);
    res.json({ ok:true, ...result });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

app.post('/api/sync/contacts', requireAuth, async (req, res) => {
  try {
    const ppl    = google.people({ version:'v1', auth:oauth2Client });
    const conts  = rj('contacts.json');
    const orgs   = rj('orgs.json');
    const result = { pushed:0, updated:0, pulled:0, errors:[] };
    const orgMap = Object.fromEntries(orgs.map(o=>[o.id,o]));

    const pushAll = async (list, isOrg=false) => {
      for (const item of list) {
        try {
          const body = buildPersonBody(item, isOrg, orgMap);
          if (item.googleContactId) {
            try {
              const { data:cur } = await ppl.people.get({ resourceName:item.googleContactId, personFields:'metadata' });
              await ppl.people.updateContact({ resourceName:item.googleContactId, updatePersonFields:'names,phoneNumbers,emailAddresses,addresses,organizations,biographies', requestBody:{ ...body, etag:cur.etag } });
              result.updated++;
            } catch { item.googleContactId = null; }
          }
          if (!item.googleContactId) {
            const { data } = await ppl.people.createContact({ requestBody: body });
            item.googleContactId = data.resourceName;
            result.pushed++;
          }
        } catch(e) { result.errors.push({ id:item.id, err:e.message }); }
      }
    };

    await pushAll(conts, false);
    await pushAll(orgs, true);

    const existingIds = new Set([...conts.filter(c=>c.googleContactId).map(c=>c.googleContactId), ...orgs.filter(o=>o.googleContactId).map(o=>o.googleContactId)]);
    let pageToken;
    do {
      const { data } = await ppl.people.connections.list({ resourceName:'people/me', pageSize:200, pageToken, personFields:'names,phoneNumbers,emailAddresses,addresses,organizations,biographies' });
      for (const gp of data.connections||[]) {
        if (existingIds.has(gp.resourceName)) continue;
        const bio = gp.biographies?.[0]?.value||'';
        if (bio.includes('[CRM-ID:')) continue;
        conts.unshift({ id:uid(), name:gp.names?.[0]?.displayName||'ללא שם', organizationId:null, role:gp.organizations?.[0]?.title||'', phone:gp.phoneNumbers?.[0]?.value||'', email:gp.emailAddresses?.[0]?.value||'', city:gp.addresses?.[0]?.city||'', status:'lead', source:'Google Contacts', notes:bio, tags:[], conversations:[], showHistory:[], nextFollowUp:'', googleContactId:gp.resourceName, createdAt:today(), fromGoogle:true });
        result.pulled++;
      }
      pageToken = data.nextPageToken;
    } while(pageToken);

    wj('contacts.json', conts);
    wj('orgs.json', orgs);
    const ss = rj('sync-status.json',{}); ss.contacts = new Date().toISOString(); wj('sync-status.json', ss);
    res.json({ ok:true, ...result });
  } catch(e) { res.status(500).json({ error:e.message }); }
});

// ─── Auto-sync status endpoint ────────────────────────────────────────────────
app.get('/api/sync-status', (req, res) => {
  const ss = rj('sync-status.json', {});
  res.json({ ...ss, autoActive: !!(loadStoredTokens()), lastPollTime });
});

// ─── Start polling (Google → CRM every 5 minutes) ────────────────────────────
const POLL_INTERVAL = 5 * 60 * 1000; // 5 minutes

// Initial pull after 15 seconds (let server stabilize first)
setTimeout(async () => {
  if (loadStoredTokens()) {
    console.log('[Auto-sync] Starting initial pull from Google...');
    await pullFromGoogle().catch(e => console.error('[Auto-sync]', e.message));
  }
}, 15000);

// Recurring pull every 5 minutes
setInterval(async () => {
  if (loadStoredTokens()) {
    console.log('[Auto-sync] Polling Google for changes...');
    await pullFromGoogle().catch(e => console.error('[Auto-sync]', e.message));
  }
}, POLL_INTERVAL);

// ─── WhatsApp (Baileys — no puppeteer) ────────────────────────────────────────
let waSock    = null;
let waStatus  = 'disconnected'; // disconnected | qr | connecting | ready
let waQR      = null;
let waBcast   = null;
let waOverdue = []; // הודעות שתוזמנו ולא נשלחו

const sleep = ms => new Promise(r => setTimeout(r, ms));

// Silent logger for Baileys (no pino dependency)
const silentLogger = {
  level: 'silent',
  trace: ()=>{}, debug: ()=>{}, info: ()=>{},
  warn: ()=>{}, error: ()=>{}, fatal: ()=>{},
  child: function() { return this; },
};

function normalizePhone(phone) {
  let d = (phone || '').replace(/\D/g, '');
  if (d.startsWith('0'))         d = '972' + d.slice(1);
  else if (!d.startsWith('972')) d = '972' + d;
  return d + '@s.whatsapp.net';
}

// ── Scheduled messages ──────────────────────────────────────────────────────
function loadScheduled()      { return rj('scheduled-wa.json', []); }
function saveScheduled(list)  { wj('scheduled-wa.json', list); }

async function sendWaMessage(phone, text) {
  if (!waSock || waStatus !== 'ready') throw new Error('WhatsApp לא מחובר');
  await waSock.sendMessage(normalizePhone(phone), { text });
}

async function runBroadcast(contacts, message, delayMs, progressObj) {
  for (let i = 0; i < contacts.length; i++) {
    const c = contacts[i];
    if (!c.phone) { if (progressObj) progressObj.failed++; continue; }
    // Sleep BETWEEN messages, not before the first one
    if (i > 0) {
      const jitter = Math.floor(Math.random() * 2000);
      await sleep(delayMs + jitter);
    }
    if (progressObj) progressObj.currentName = c.name;
    const msg = message.replace(/\{\{name\}\}/g, c.name||'').replace(/\{\{שם\}\}/g, c.name||'');
    try {
      await sendWaMessage(c.phone, msg);
      if (progressObj) { progressObj.sent++; progressObj.lastSentAt = Date.now(); }
      console.log(`[WA] ✅ ${c.name}`);
    } catch(e) {
      if (progressObj) { progressObj.failed++; progressObj.errors.push({ name:c.name, error:e.message }); }
      console.error(`[WA] ❌ ${c.name}:`, e.message);
    }
  }
  if (progressObj) { progressObj.done = true; progressObj.currentName = ''; }
}

// Check scheduled messages every minute
setInterval(async () => {
  if (waStatus !== 'ready') return;
  const now  = new Date();
  const list = loadScheduled();
  let dirty  = false;
  for (const item of list) {
    if (item.status !== 'pending') continue;
    if (new Date(item.scheduleAt) > now) continue;
    dirty = true;
    item.status = 'sending';
    console.log(`[WA Scheduler] מריץ: ${item.type} #${item.id}`);
    if (item.type === 'single') {
      try {
        await sendWaMessage(item.phone, item.message);
        item.status = 'sent';
        console.log(`[WA Scheduler] ✅ נשלח ל-${item.phone}`);
      } catch(e) { item.status = 'failed'; item.error = e.message; }
    } else {
      item.status = 'sent';
      runBroadcast(item.contacts, item.message, item.delayMs||7000, null)
        .then(()=>console.log(`[WA Scheduler] ✅ ברודקאסט הסתיים`))
        .catch(e=>console.error('[WA Scheduler]', e.message));
    }
  }
  if (dirty) saveScheduled(list);
}, 60 * 1000);

// ── Baileys init ─────────────────────────────────────────────────────────────
async function initWA() {
  if (waStatus !== 'disconnected') return;
  let makeWASocket, useMultiFileAuthState, DisconnectReason, QRCode;
  try {
    ({ default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys'));
    QRCode = require('qrcode');
  } catch(e) {
    console.error('[WA] חבילות חסרות — הרץ: npm install');
    return;
  }
  waStatus = 'connecting';
  console.log('[WA] שלב 1: מכין session...');
  const sessionDir = path.join(DATA, 'wa-session');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir, { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  console.log('[WA] שלב 2: מביא גרסת WhatsApp עדכנית...');
  let waVersion;
  try { const v = await fetchLatestBaileysVersion(); waVersion = v.version; console.log('[WA] גרסה:', waVersion); }
  catch { waVersion = [2,3000,1023459663]; console.log('[WA] משתמש בגרסה ברירת מחדל'); }
  console.log('[WA] שלב 3: יוצר socket...');
  const sock = makeWASocket({
    version: waVersion,
    auth: state,
    printQRInTerminal: false,
    logger: silentLogger,
    browser: ['CRM-Shakuf', 'Chrome', '124.0.0.0'],
    connectTimeoutMs: 30000,
    defaultQueryTimeoutMs: 30000,
  });
  console.log('[WA] שלב 4: socket נוצר, ממתין לאירועים...');
  waSock = sock;

  sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      waStatus = 'qr';
      try { waQR = await QRCode.toDataURL(qr); } catch {}
      console.log('[WA] QR מוכן — סרוק בהגדרות');
    }
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      const loggedOut = code === DisconnectReason?.loggedOut;
      waSock = null; waStatus = 'disconnected'; waQR = null;
      const errMsg = lastDisconnect?.error?.message || lastDisconnect?.error || 'unknown';
      console.log('[WA] חיבור נסגר. קוד:', code, '| שגיאה:', errMsg);
      if (!loggedOut) { console.log('[WA] מתחבר מחדש...'); setTimeout(initWA, 5000); }
      else              console.log('[WA] נותק — יש לסרוק QR מחדש');
    } else if (connection === 'open') {
      waStatus = 'ready'; waQR = null;
      console.log('[WA] ✅ מחובר ומוכן');
      // בדוק הודעות שתוזמנו ולא נשלחו
      const now = new Date();
      const overdue = loadScheduled().filter(m => m.status === 'pending' && new Date(m.scheduleAt) <= now);
      if (overdue.length > 0) {
        waOverdue = overdue;
        console.log(`[WA] נמצאו ${overdue.length} הודעות שלא נשלחו`);
      }
    }
  });
  sock.ev.on('creds.update', saveCreds);
}

// Auto-connect if session exists
const WA_SESSION_DIR = path.join(DATA, 'wa-session');
if (fs.existsSync(WA_SESSION_DIR) && fs.readdirSync(WA_SESSION_DIR).length > 0) {
  console.log('[WA] נמצא session — מתחבר אוטומטית...');
  setTimeout(initWA, 3000);
}

// ── WA API routes ─────────────────────────────────────────────────────────────
app.get('/api/wa/status', (req, res) => {
  res.json({ status: waStatus, qr: waQR, broadcast: waBcast, scheduled: loadScheduled(), overdue: waOverdue });
});

app.post('/api/wa/connect', async (req, res) => {
  await initWA();
  res.json({ ok: true, status: waStatus });
});

app.post('/api/wa/disconnect', async (req, res) => {
  if (waSock) { try { await waSock.logout(); } catch {} waSock = null; }
  waStatus = 'disconnected'; waQR = null;
  const sd = path.join(DATA, 'wa-session');
  if (fs.existsSync(sd)) fs.rmSync(sd, { recursive: true, force: true });
  res.json({ ok: true });
});

app.post('/api/wa/send', async (req, res) => {
  const { phone, message, scheduleAt } = req.body;
  if (!phone)    return res.status(400).json({ error: 'חסר מספר טלפון' });
  if (!message)  return res.status(400).json({ error: 'חסרה הודעה' });

  // ── Scheduled ──
  if (scheduleAt) {
    const list = loadScheduled();
    const item = { id: uid(), type:'single', phone, message, scheduleAt, status:'pending', createdAt: new Date().toISOString() };
    list.push(item);
    saveScheduled(list);
    return res.json({ ok:true, scheduled:true, id:item.id });
  }

  // ── Immediate ──
  try { await sendWaMessage(phone, message); res.json({ ok:true }); }
  catch(e) { res.status(400).json({ error: e.message }); }
});

app.post('/api/wa/broadcast', async (req, res) => {
  const { contacts, message, delayMs = 7000, scheduleAt } = req.body;
  if (!contacts?.length) return res.status(400).json({ error: 'אין אנשי קשר' });

  // ── Scheduled ──
  if (scheduleAt) {
    const list = loadScheduled();
    const item = { id: uid(), type:'broadcast', contacts, message, delayMs, scheduleAt, status:'pending', createdAt: new Date().toISOString() };
    list.push(item);
    saveScheduled(list);
    return res.json({ ok:true, scheduled:true, id:item.id });
  }

  // ── Immediate ──
  if (waStatus !== 'ready') return res.status(400).json({ error: 'WhatsApp לא מחובר' });
  if (waBcast && !waBcast.done) return res.status(400).json({ error: 'שליחה כבר בתהליך' });
  waBcast = { total: contacts.length, sent:0, failed:0, done:false, errors:[] };
  res.json({ ok:true, total: contacts.length });
  runBroadcast(contacts, message, delayMs, waBcast);
});

app.delete('/api/wa/scheduled/:id', (req, res) => {
  saveScheduled(loadScheduled().filter(x => x.id !== req.params.id));
  res.json({ ok:true });
});

// הודעות שתוזמנו ולא נשלחו (overdue)
app.get('/api/wa/overdue', (req, res) => {
  res.json({ items: waOverdue });
});

app.post('/api/wa/overdue/send', async (req, res) => {
  if (waStatus !== 'ready') return res.status(400).json({ error: 'WA לא מחובר' });
  const items = [...waOverdue];
  waOverdue = [];
  res.json({ ok: true, count: items.length });
  // שלח בצורה אסינכרונית
  for (const item of items) {
    try {
      if (item.type === 'single') {
        await sendWaMessage(item.phone, item.message);
      } else {
        runBroadcast(item.contacts, item.message, item.delayMs || 7000, null);
      }
      const list = loadScheduled();
      const idx = list.findIndex(x => x.id === item.id);
      if (idx !== -1) { list[idx].status = 'sent'; saveScheduled(list); }
    } catch(e) {
      const list = loadScheduled();
      const idx = list.findIndex(x => x.id === item.id);
      if (idx !== -1) { list[idx].status = 'failed'; list[idx].error = e.message; saveScheduled(list); }
    }
  }
});

app.post('/api/wa/overdue/dismiss', (req, res) => {
  waOverdue = [];
  res.json({ ok: true });
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.get('*', (req, res) => res.sendFile(path.join(PUB, 'index.html')));

app.listen(PORT, () => {
  console.log('\n🎭  CRM שקוף בחזית');
  console.log(`✅  רץ על http://localhost:${PORT}`);
  const tokens = loadStoredTokens();
  if (tokens) {
    console.log('🔄  סנכרון אוטומטי פעיל — דוחף שינויים לגוגל מיד, מושך כל 5 דקות');
  } else {
    console.log('⚠️   כדי להפעיל סנכרון אוטומטי: התחבר לגוגל בהגדרות');
  }
  if (!process.env.GOOGLE_CLIENT_ID) {
    console.log('⚠️   לסנכרון גוגל: ערוך את קובץ .env עם GOOGLE_CLIENT_ID ו-GOOGLE_CLIENT_SECRET');
  }
});
