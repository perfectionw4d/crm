@echo off
chcp 65001 > /dev/null
echo.
echo  ===================================
echo    שקוף בחזית - CRM
echo  ===================================
echo.
echo  מפעיל שרת...
echo  פתח את הדפדפן בכתובת: http://localhost:3000
echo.
node server.js
pause
