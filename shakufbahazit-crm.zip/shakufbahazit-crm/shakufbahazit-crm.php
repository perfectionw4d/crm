<?php
/**
 * Plugin Name: שקוף בחזית CRM Bridge
 * Description: מקשר בין מערכת ה-CRM של ירון אנטניר לאתר WordPress — הצעות מחיר, הזמנות וחתימה דיגיטלית
 * Version: 1.0
 * Author: ירון אנטניר — שקוף בחזית
 */

if (!defined('ABSPATH')) exit;

// ─── Activation / Deactivation ──────────────────────────────────────────────
register_activation_hook(__FILE__, 'shb_activate');
function shb_activate() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    $tbl = $wpdb->prefix . 'shb_events';
    $sql = "CREATE TABLE IF NOT EXISTS $tbl (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        event_type varchar(50) NOT NULL,
        ref_id varchar(100) NOT NULL,
        contact_id varchar(100) DEFAULT '',
        data longtext,
        processed tinyint(1) DEFAULT 0,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY event_type (event_type),
        KEY processed (processed)
    ) $charset;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
    shb_add_rewrite_rules();
    flush_rewrite_rules();
}

register_deactivation_hook(__FILE__, function() { flush_rewrite_rules(); });

// ─── Rewrite Rules ───────────────────────────────────────────────────────────
add_action('init', 'shb_add_rewrite_rules');
function shb_add_rewrite_rules() {
    add_rewrite_rule('^offers/([^/]+)/?$', 'index.php?shb_offer_id=$matches[1]', 'top');
    add_rewrite_rule('^orders/([^/]+)/?$', 'index.php?shb_order_id=$matches[1]', 'top');
}

add_filter('query_vars', function($v) {
    $v[] = 'shb_offer_id';
    $v[] = 'shb_order_id';
    return $v;
});

add_action('template_redirect', 'shb_template_redirect');
function shb_template_redirect() {
    $offer_id = get_query_var('shb_offer_id');
    $order_id = get_query_var('shb_order_id');
    if ($offer_id) { shb_serve_offer($offer_id); exit; }
    if ($order_id) { shb_serve_order($order_id); exit; }
}

// ─── Serve Offer Page ────────────────────────────────────────────────────────
function shb_serve_offer($id) {
    $offer   = get_option('shb_offer_' . $id);
    $html_file = WP_CONTENT_DIR . '/shb-offers/' . $id . '.html';
    if (!$offer || !file_exists($html_file)) {
        status_header(404);
        echo shb_404_page('הצעת מחיר לא נמצאה');
        return;
    }
    // Track view (once per hour per visitor)
    $last = intval($offer['last_viewed'] ?? 0);
    if (time() - $last > 3600) {
        $offer['last_viewed'] = time();
        $offer['viewed']      = true;
        update_option('shb_offer_' . $id, $offer);
        global $wpdb;
        $wpdb->insert($wpdb->prefix . 'shb_events', [
            'event_type' => 'offer_viewed',
            'ref_id'     => $id,
            'contact_id' => $offer['contact_id'] ?? '',
            'data'       => json_encode([
                'offer_id'   => $id,
                'contact_id' => $offer['contact_id'] ?? '',
                'viewed_at'  => date('c'),
            ]),
            'processed'  => 0,
        ]);
    }
    header('Content-Type: text/html; charset=utf-8');
    echo file_get_contents($html_file);
}

// ─── Serve Order Page (with signature canvas) ────────────────────────────────
function shb_serve_order($id) {
    $order     = get_option('shb_order_' . $id);
    $html_file = WP_CONTENT_DIR . '/shb-orders/' . $id . '.html';
    if (!$order || !file_exists($html_file)) {
        status_header(404);
        echo shb_404_page('הזמנה לא נמצאה');
        return;
    }
    header('Content-Type: text/html; charset=utf-8');
    $html = file_get_contents($html_file);

    // If already signed — replace print button area with confirmation
    if (!empty($order['signed'])) {
        $signed_at = $order['signed_at'] ?? '';
        $dt = new DateTime($signed_at);
        $dt->setTimezone(new DateTimeZone('Asia/Jerusalem'));
        $formatted = $dt->format('d/m/Y H:i');
        $confirmation = '<div style="max-width:210mm;margin:20px auto;padding:24px;font-family:Heebo,Arial,sans-serif;direction:rtl;text-align:center;background:#f0fdf4;border-radius:12px;border:2px solid #bbf7d0">
            <div style="font-size:52px;margin-bottom:12px">✅</div>
            <h2 style="color:#166534;font-size:22px;font-weight:700;margin-bottom:8px">ההזמנה אושרה ונחתמה!</h2>
            <p style="color:#15803d;font-size:14px">זמן חתימה: ' . esc_html($formatted) . '</p>
        </div>';
        $html = str_replace('</body>', $confirmation . '</body>', $html);
        echo $html;
        return;
    }

    $id_json   = json_encode($id);
    $site_url  = json_encode(get_site_url());
    $sig_block = '
<link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;600;700&display=swap" rel="stylesheet">
<div id="shb-sig-section" style="max-width:210mm;margin:0 auto;padding:16px 24px 32px;font-family:Heebo,Arial,sans-serif;direction:rtl">
  <div style="background:#f8fafc;border:2px solid #c7d2fe;border-radius:14px;padding:22px">
    <h3 style="font-size:17px;font-weight:700;color:#2d4a7a;margin:0 0 14px">✍️ אישור ההזמנה</h3>
    <div style="display:flex;gap:0;margin-bottom:16px;border:1.5px solid #e2e8f0;border-radius:9px;overflow:hidden;width:fit-content">
      <button id="shb-tab-draw" onclick="shbTab(\'draw\')"
        style="background:#2d4a7a;color:white;border:none;padding:9px 22px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit">
        ✍️ חתימה
      </button>
      <button id="shb-tab-upload" onclick="shbTab(\'upload\')"
        style="background:#f1f5f9;color:#475569;border:none;padding:9px 22px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit">
        📷 העלאת תמונה
      </button>
    </div>
    <div id="shb-panel-draw">
      <p style="font-size:13px;color:#64748b;margin:0 0 10px">חתום בתיבה למטה עם העכבר, האצבע או עט דיגיטלי</p>
      <canvas id="shb-canvas" width="700" height="200"
        style="border:2px solid #cbd5e1;border-radius:10px;background:white;cursor:crosshair;touch-action:none;width:100%;max-width:700px;display:block;margin:0 auto"></canvas>
      <div style="display:flex;justify-content:center;margin-top:10px">
        <button onclick="shbClear()" style="background:#f1f5f9;color:#475569;border:1.5px solid #e2e8f0;border-radius:9px;padding:8px 20px;font-size:13px;cursor:pointer;font-family:inherit;font-weight:600">🗑️ נקה</button>
      </div>
    </div>
    <div id="shb-panel-upload" style="display:none">
      <p style="font-size:13px;color:#64748b;margin:0 0 10px">העלה תמונה של החתימה שלך (JPG, PNG)</p>
      <input type="file" id="shb-file" accept="image/*"
        style="display:block;margin-bottom:12px;font-family:inherit;font-size:13px;cursor:pointer"/>
      <div id="shb-img-preview" style="display:none;text-align:center">
        <img id="shb-img" style="max-width:100%;max-height:200px;border:2px solid #e2e8f0;border-radius:10px;display:inline-block"/>
      </div>
    </div>
    <div style="display:flex;justify-content:center;margin-top:16px">
      <button onclick="shbSubmit()" id="shb-submit"
        style="background:#2d4a7a;color:white;border:none;border-radius:9px;padding:10px 32px;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit">
        ✅ שלח ואשר הזמנה
      </button>
    </div>
    <div id="shb-status" style="margin-top:12px;font-size:13px;text-align:center;min-height:20px;color:#dc2626"></div>
  </div>
</div>
<script>
(function(){
  var mode = "draw";
  var uploadedData = null;

  var canvas = document.getElementById("shb-canvas");
  var ctx    = canvas.getContext("2d");
  var drawing = false, lx = 0, ly = 0;

  function scale(e) {
    var r  = canvas.getBoundingClientRect();
    var sx = canvas.width  / r.width;
    var sy = canvas.height / r.height;
    var src = e.touches ? e.touches[0] : e;
    return { x: (src.clientX - r.left) * sx, y: (src.clientY - r.top) * sy };
  }
  function start(e){ e.preventDefault(); drawing=true; var p=scale(e); lx=p.x; ly=p.y; }
  function move(e){
    e.preventDefault();
    if(!drawing) return;
    var p=scale(e);
    ctx.beginPath(); ctx.moveTo(lx,ly); ctx.lineTo(p.x,p.y);
    ctx.strokeStyle="#1e293b"; ctx.lineWidth=2.5; ctx.lineCap="round"; ctx.stroke();
    lx=p.x; ly=p.y;
  }
  function stop(){ drawing=false; }

  canvas.addEventListener("mousedown",  start, {passive:false});
  canvas.addEventListener("touchstart", start, {passive:false});
  canvas.addEventListener("mousemove",  move,  {passive:false});
  canvas.addEventListener("touchmove",  move,  {passive:false});
  canvas.addEventListener("mouseup",    stop);
  canvas.addEventListener("touchend",   stop);

  window.shbClear = function(){ ctx.clearRect(0,0,canvas.width,canvas.height); };

  window.shbTab = function(t) {
    mode = t;
    document.getElementById("shb-panel-draw").style.display   = t==="draw"   ? "block" : "none";
    document.getElementById("shb-panel-upload").style.display = t==="upload" ? "block" : "none";
    document.getElementById("shb-tab-draw").style.background   = t==="draw"   ? "#2d4a7a" : "#f1f5f9";
    document.getElementById("shb-tab-draw").style.color        = t==="draw"   ? "white"   : "#475569";
    document.getElementById("shb-tab-upload").style.background = t==="upload" ? "#2d4a7a" : "#f1f5f9";
    document.getElementById("shb-tab-upload").style.color      = t==="upload" ? "white"   : "#475569";
  };

  document.getElementById("shb-file").addEventListener("change", function(){
    var file = this.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function(e){
      uploadedData = e.target.result;
      document.getElementById("shb-img").src = uploadedData;
      document.getElementById("shb-img-preview").style.display = "block";
    };
    reader.readAsDataURL(file);
  });

  window.shbSubmit = async function(){
    var sigData;
    var statusEl = document.getElementById("shb-status");
    if (mode === "draw") {
      var imgData = ctx.getImageData(0,0,canvas.width,canvas.height).data;
      var empty = true;
      for(var i=3;i<imgData.length;i+=4){ if(imgData[i]>0){ empty=false; break; } }
      if(empty){ statusEl.textContent="⚠️ נא לחתום לפני השליחה"; return; }
      sigData = canvas.toDataURL("image/png");
    } else {
      if(!uploadedData){ statusEl.textContent="⚠️ נא לבחור תמונה"; return; }
      sigData = uploadedData;
    }
    var btn = document.getElementById("shb-submit");
    btn.disabled=true; btn.textContent="שולח...";
    statusEl.textContent="";
    try{
      var resp = await fetch(' . $site_url . ' + "/wp-json/shb-crm/v1/orders/" + ' . $id_json . ' + "/sign", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({ signature: sigData, signed_at: new Date().toISOString() })
      });
      var result = await resp.json();
      if(result.success){
        document.getElementById("shb-sig-section").innerHTML =
          \'<div style="text-align:center;padding:48px 24px;background:#f0fdf4;border-radius:14px;border:2px solid #bbf7d0;margin:20px 0">\' +
          \'<div style="font-size:56px;margin-bottom:14px">✅</div>\' +
          \'<h2 style="color:#166534;font-size:22px;font-weight:700;margin-bottom:8px">ההזמנה אושרה!</h2>\' +
          \'<p style="color:#15803d;font-size:14px">החתימה התקבלה. ירון יחזור אליך בהקדם 🙏</p></div>\';
      } else {
        statusEl.textContent = "❌ שגיאה: " + (result.error||"נסה שוב");
        btn.disabled=false; btn.textContent="✅ שלח ואשר הזמנה";
      }
    } catch(err){
      statusEl.textContent = "❌ שגיאת רשת — נסה שוב";
      btn.disabled=false; btn.textContent="✅ שלח ואשר הזמנה";
    }
  };
})();
</script>';

    // Inject into placeholder if present, otherwise before </body>
    if (strpos($html, '<div id="shb-sig-target"></div>') !== false) {
        $html = str_replace('<div id="shb-sig-target"></div>', $sig_block, $html);
    } else {
        $html = str_replace('</body>', $sig_block . '</body>', $html);
    }
    echo $html;
}

function shb_404_page($msg) {
    return '<!DOCTYPE html><html dir="rtl" lang="he"><head><meta charset="UTF-8">
    <style>body{font-family:Arial,sans-serif;text-align:center;padding:120px 20px;color:#475569}
    h1{font-size:28px;color:#2d4a7a;margin-bottom:12px}.sub{font-size:15px}</style></head>
    <body><h1>404</h1><p class="sub">' . esc_html($msg) . '</p>
    <p><a href="https://shakufbahazit.co.il" style="color:#4f46e5">→ חזרה לאתר</a></p></body></html>';
}

// ─── REST API ────────────────────────────────────────────────────────────────
add_action('rest_api_init', function() {
    $auth = 'shb_check_auth';

    // Push offer
    register_rest_route('shb-crm/v1', '/offers', [
        'methods'             => 'POST',
        'callback'            => 'shb_push_offer',
        'permission_callback' => $auth,
    ]);
    // Push order
    register_rest_route('shb-crm/v1', '/orders', [
        'methods'             => 'POST',
        'callback'            => 'shb_push_order',
        'permission_callback' => $auth,
    ]);
    // Get pending events
    register_rest_route('shb-crm/v1', '/events', [
        'methods'             => 'GET',
        'callback'            => 'shb_get_events',
        'permission_callback' => $auth,
    ]);
    // Acknowledge events
    register_rest_route('shb-crm/v1', '/events/ack', [
        'methods'             => 'POST',
        'callback'            => 'shb_ack_events',
        'permission_callback' => $auth,
    ]);
    // Sign order (public)
    register_rest_route('shb-crm/v1', '/orders/(?P<id>[^/]+)/sign', [
        'methods'             => 'POST',
        'callback'            => 'shb_sign_order',
        'permission_callback' => '__return_true',
    ]);
    // WhatsApp Webhook — verification (GET)
    register_rest_route('shb-crm/v1', '/wa/webhook', [
        'methods'             => 'GET',
        'callback'            => 'shb_wa_webhook_verify',
        'permission_callback' => '__return_true',
    ]);
    // WhatsApp Webhook — incoming messages (POST)
    register_rest_route('shb-crm/v1', '/wa/webhook', [
        'methods'             => 'POST',
        'callback'            => 'shb_wa_webhook_receive',
        'permission_callback' => '__return_true',
    ]);
    // Health check
    register_rest_route('shb-crm/v1', '/ping', [
        'methods'             => 'GET',
        'callback'            => function() { return ['ok' => true, 'version' => '1.0']; },
        'permission_callback' => $auth,
    ]);
});

function shb_check_auth($req) {
    $key = get_option('shb_api_key', '');
    if (empty($key)) return true; // dev mode
    return $req->get_header('X-CRM-Key') === $key;
}

function shb_push_offer($req) {
    $d    = $req->get_json_params();
    $id   = sanitize_text_field($d['id'] ?? '');
    if (!$id) return new WP_Error('missing', 'Missing id', ['status' => 400]);
    $html = $d['html'] ?? ''; // Store raw HTML — no sanitization (trusted source)
    // Save HTML to file for large content support
    $dir = WP_CONTENT_DIR . '/shb-offers/';
    if (!file_exists($dir)) wp_mkdir_p($dir);
    file_put_contents($dir . $id . '.html', $html);
    update_option('shb_offer_' . $id, [
        'id'           => $id,
        'contact_id'   => sanitize_text_field($d['contact_id'] ?? ''),
        'contact_name' => sanitize_text_field($d['contact_name'] ?? ''),
        'created_at'   => date('c'),
        'viewed'       => false,
        'last_viewed'  => 0,
    ], false);
    return ['success' => true, 'url' => home_url('/offers/' . $id . '/')];
}

function shb_push_order($req) {
    $d    = $req->get_json_params();
    $id   = sanitize_text_field($d['id'] ?? '');
    if (!$id) return new WP_Error('missing', 'Missing id', ['status' => 400]);
    $html = $d['html'] ?? '';
    $dir  = WP_CONTENT_DIR . '/shb-orders/';
    if (!file_exists($dir)) wp_mkdir_p($dir);
    file_put_contents($dir . $id . '.html', $html);
    update_option('shb_order_' . $id, [
        'id'           => $id,
        'contact_id'   => sanitize_text_field($d['contact_id'] ?? ''),
        'contact_name' => sanitize_text_field($d['contact_name'] ?? ''),
        'quote_id'     => sanitize_text_field($d['quote_id'] ?? ''),
        'created_at'   => date('c'),
        'signed'       => false,
    ], false);
    return ['success' => true, 'url' => home_url('/orders/' . $id . '/')];
}

function shb_get_events() {
    global $wpdb;
    $tbl    = $wpdb->prefix . 'shb_events';
    $events = $wpdb->get_results("SELECT * FROM $tbl WHERE processed=0 ORDER BY created_at ASC LIMIT 100", ARRAY_A);
    return ['events' => $events ?: []];
}

function shb_ack_events($req) {
    $ids = $req->get_json_params()['ids'] ?? [];
    if (empty($ids)) return ['success' => true];
    global $wpdb;
    $tbl  = $wpdb->prefix . 'shb_events';
    $ph   = implode(',', array_fill(0, count($ids), '%d'));
    $wpdb->query($wpdb->prepare("UPDATE $tbl SET processed=1 WHERE id IN ($ph)", ...$ids));
    return ['success' => true];
}

function shb_sign_order($req) {
    $id    = $req->get_param('id');
    $d     = $req->get_json_params();
    $sig   = $d['signature']  ?? '';
    $ts    = $d['signed_at']  ?? date('c');

    // Capture signer IP (supports Cloudflare, proxies, direct)
    $ip = '';
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
        if (!empty($_SERVER[$key])) {
            $ip = trim(explode(',', $_SERVER[$key])[0]);
            break;
        }
    }

    $order = get_option('shb_order_' . $id);
    if (!$order)           return new WP_Error('not_found', 'Order not found', ['status' => 404]);
    if ($order['signed'])  return new WP_Error('already',   'Already signed',  ['status' => 409]);

    $order['signed']    = true;
    $order['signed_at'] = $ts;
    $order['signature'] = $sig;
    $order['signer_ip'] = $ip;
    update_option('shb_order_' . $id, $order, false);

    // Log event for CRM polling
    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'shb_events', [
        'event_type' => 'order_signed',
        'ref_id'     => $id,
        'contact_id' => $order['contact_id'],
        'data'       => json_encode([
            'order_id'   => $id,
            'contact_id' => $order['contact_id'],
            'signed_at'  => $ts,
            'signature'  => $sig,
            'signer_ip'  => $ip,
        ]),
        'processed'  => 0,
    ]);

    // Send WhatsApp
    shb_send_whatsapp($id, $order, $ts);

    return ['success' => true];
}

// ─── WhatsApp Notification ───────────────────────────────────────────────────
function shb_send_whatsapp($order_id, $order, $signed_at) {
    $token    = get_option('shb_wa_token',    '');
    $phone_id = get_option('shb_wa_phone_id', '');
    $to       = get_option('shb_notify_phone','972525105100');
    if (!$token || !$phone_id) return;

    $name = $order['contact_name'] ?? '';
    $dt   = new DateTime($signed_at);
    $dt->setTimezone(new DateTimeZone('Asia/Jerusalem'));
    $fmt  = $dt->format('d/m/Y H:i');

    $msg = "✍️ *הזמנה חתומה!*\n\nלקוח: *{$name}*\nהזמנה מס׳: {$order_id}\nזמן חתימה: {$fmt}";

    wp_remote_post("https://graph.facebook.com/v18.0/{$phone_id}/messages", [
        'headers' => [
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json',
        ],
        'body'    => json_encode([
            'messaging_product' => 'whatsapp',
            'to'                => $to,
            'type'              => 'text',
            'text'              => ['body' => $msg],
        ]),
        'timeout' => 15,
    ]);
}

// ─── WhatsApp Webhook (incoming messages from Meta) ──────────────────────────

function shb_wa_webhook_verify($req) {
    $mode      = $req->get_param('hub_mode');
    $token     = $req->get_param('hub_verify_token');
    $challenge = $req->get_param('hub_challenge');
    $stored    = get_option('shb_wa_verify_token', '');
    if ($mode === 'subscribe' && $token === $stored && $stored !== '') {
        // Must return raw integer, not JSON
        status_header(200);
        echo intval($challenge);
        exit;
    }
    return new WP_Error('forbidden', 'Forbidden', ['status' => 403]);
}

function shb_wa_webhook_receive($req) {
    $body = $req->get_json_params();
    if (($body['object'] ?? '') !== 'whatsapp_business_account') {
        return ['ok' => true]; // not a WA event, just acknowledge
    }
    global $wpdb;
    $tbl = $wpdb->prefix . 'shb_events';

    foreach (($body['entry'] ?? []) as $entry) {
        foreach (($entry['changes'] ?? []) as $change) {
            $value = $change['value'] ?? [];

            // ── Incoming messages ──────────────────────────────────────────
            foreach (($value['messages'] ?? []) as $msg) {
                $from  = $msg['from']      ?? '';
                $msgId = $msg['id']        ?? '';
                $type  = $msg['type']      ?? 'text';
                $ts    = intval($msg['timestamp'] ?? time());

                // Extract text content by type
                $text = '';
                switch ($type) {
                    case 'text':        $text = $msg['text']['body']                                  ?? ''; break;
                    case 'button':      $text = '[כפתור] ' . ($msg['button']['text']                  ?? ''); break;
                    case 'interactive': $text = '[אינטראקטיבי] ' . ($msg['interactive']['button_reply']['title'] ?? ($msg['interactive']['list_reply']['title'] ?? '')); break;
                    case 'image':       $text = '[תמונה]';   break;
                    case 'audio':       $text = '[הודעה קולית]'; break;
                    case 'video':       $text = '[וידאו]';   break;
                    case 'document':    $text = '[מסמך] ' . ($msg['document']['filename'] ?? ''); break;
                    case 'sticker':     $text = '[מדבקה]';   break;
                    case 'location':    $text = '[מיקום]';   break;
                    default:            $text = '[' . $type . ']';
                }

                // Get sender display name from webhook contacts array
                $senderName = '';
                foreach (($value['contacts'] ?? []) as $c) {
                    if ($c['wa_id'] === $from) {
                        $senderName = $c['profile']['name'] ?? '';
                        break;
                    }
                }

                $wpdb->insert($tbl, [
                    'event_type' => 'wa_incoming',
                    'ref_id'     => $msgId,
                    'contact_id' => '',
                    'data'       => json_encode([
                        'msg_id'    => $msgId,
                        'from'      => $from,
                        'name'      => $senderName,
                        'text'      => $text,
                        'type'      => $type,
                        'timestamp' => $ts,
                    ]),
                    'processed'  => 0,
                ]);
            }

            // ── Status updates (delivered, read) — just acknowledge ────────
            foreach (($value['statuses'] ?? []) as $status) {
                $wpdb->insert($tbl, [
                    'event_type' => 'wa_status',
                    'ref_id'     => $status['id'] ?? '',
                    'contact_id' => '',
                    'data'       => json_encode($status),
                    'processed'  => 0,
                ]);
            }
        }
    }
    return ['ok' => true];
}

// ─── Admin Settings Page ─────────────────────────────────────────────────────
add_action('admin_menu', function() {
    add_options_page('שקוף בחזית CRM', 'CRM Bridge', 'manage_options', 'shb-crm', 'shb_settings_page');
});

function shb_settings_page() {
    if (isset($_POST['shb_save']) && check_admin_referer('shb_settings')) {
        $fields = ['shb_api_key','shb_wa_token','shb_wa_phone_id','shb_notify_phone','shb_wa_verify_token'];
        foreach ($fields as $f) update_option($f, sanitize_text_field($_POST[$f] ?? ''));
        echo '<div class="updated"><p>✅ ההגדרות נשמרו בהצלחה</p></div>';
    }
    $api_key         = get_option('shb_api_key',         '');
    $wa_token        = get_option('shb_wa_token',        '');
    $wa_phone_id     = get_option('shb_wa_phone_id',     '');
    $notify_phone    = get_option('shb_notify_phone',    '972525105100');
    $wa_verify_token = get_option('shb_wa_verify_token', '');
    ?>
    <div class="wrap" dir="rtl" style="font-family:Arial,sans-serif">
      <h1 style="margin-bottom:20px">🎤 שקוף בחזית — CRM Bridge</h1>
      <form method="post">
        <?php wp_nonce_field('shb_settings'); ?>
        <table class="form-table">
          <tr>
            <th scope="row">מפתח API סודי</th>
            <td>
              <input type="text" name="shb_api_key" value="<?php echo esc_attr($api_key); ?>"
                class="regular-text" placeholder="הזן מפתח זהה לזה שב-.env של ה-CRM"/>
              <p class="description">הגדר כאן מפתח, ואותו מפתח ב-.env: WP_API_KEY=...</p>
            </td>
          </tr>
          <tr>
            <th scope="row">WhatsApp Access Token</th>
            <td><input type="password" name="shb_wa_token" value="<?php echo esc_attr($wa_token); ?>" class="regular-text" placeholder="EAA..."/></td>
          </tr>
          <tr>
            <th scope="row">WhatsApp Phone Number ID</th>
            <td><input type="text" name="shb_wa_phone_id" value="<?php echo esc_attr($wa_phone_id); ?>" class="regular-text" placeholder="1023916780811453"/></td>
          </tr>
          <tr>
            <th scope="row">מספר לקבלת התראות (WhatsApp)</th>
            <td>
              <input type="text" name="shb_notify_phone" value="<?php echo esc_attr($notify_phone); ?>" class="regular-text" placeholder="972525105100"/>
              <p class="description">בפורמט בינלאומי ללא + (לדוגמה: 972525105100)</p>
            </td>
          </tr>
          <tr>
            <th scope="row">Webhook Verify Token</th>
            <td>
              <input type="text" name="shb_wa_verify_token" value="<?php echo esc_attr($wa_verify_token); ?>" class="regular-text" placeholder="מחרוזת סודית כלשהי..."/>
              <p class="description">מחרוזת שתזין גם בהגדרות ה-Webhook של Meta (Verify Token). לדוגמה: <code>shb-secret-2026</code></p>
            </td>
          </tr>
        </table>
        <p class="submit">
          <input type="submit" name="shb_save" class="button-primary" value="💾 שמור הגדרות"/>
        </p>
      </form>
      <hr>
      <h2>🔗 כתובות URL</h2>
      <table class="widefat" style="max-width:700px">
        <tr><td><strong>הצעות מחיר:</strong></td><td><code><?php echo home_url('/offers/{מספר}/'); ?></code></td></tr>
        <tr><td><strong>הזמנות:</strong></td><td><code><?php echo home_url('/orders/{מספר}/'); ?></code></td></tr>
        <tr><td><strong>בדיקת חיבור:</strong></td><td><code><?php echo rest_url('shb-crm/v1/ping'); ?></code></td></tr>
        <tr style="background:#fff9db">
          <td><strong>📲 WhatsApp Webhook URL:</strong><br/><small style="color:#856404">הכנס כתובת זו ב-Meta Developer Console</small></td>
          <td><code style="font-size:13px;color:#856404"><?php echo rest_url('shb-crm/v1/wa/webhook'); ?></code></td>
        </tr>
      </table>
      <hr>
      <h2>📋 הוראות התקנה</h2>
      <ol style="line-height:2;font-size:14px">
        <li>הגדר את ה<strong>מפתח API</strong> כאן ואותו מפתח ב-.env של ה-CRM: <code>WP_API_KEY=המפתח</code></li>
        <li>הכנס את פרטי ה-<strong>WhatsApp</strong> (Token + Phone ID) — אותם פרטים שב-.env של ה-CRM</li>
        <li>הפעל מחדש את שרת ה-CRM לאחר שינוי ה-.env</li>
        <li>לחץ "בדוק חיבור" ב-CRM כדי לאמת שהכל עובד</li>
      </ol>
    </div>
    <?php
}
